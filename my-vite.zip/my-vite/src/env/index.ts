const SERVER_URL = import.meta.env.VITE_API_BASE_URL;

export const APP_ENV = {
    SERVER_URL
}
