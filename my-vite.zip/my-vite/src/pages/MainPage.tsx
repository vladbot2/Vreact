const MainPage = () => {
    return (
        <>

        </>)
}


export default MainPage