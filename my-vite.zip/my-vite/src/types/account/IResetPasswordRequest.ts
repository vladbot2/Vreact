export interface IForgotPassword {
    email: string;
}