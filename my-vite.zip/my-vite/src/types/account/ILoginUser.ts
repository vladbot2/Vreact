export interface ILoginUser {
    username:string;
    password:string;
}